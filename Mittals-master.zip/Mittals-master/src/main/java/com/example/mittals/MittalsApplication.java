package com.example.mittals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MittalsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MittalsApplication.class, args);
    }

}
